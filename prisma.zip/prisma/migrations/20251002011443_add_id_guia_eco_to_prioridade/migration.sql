-- AlterTable
ALTER TABLE "Prioridade" ADD COLUMN     "idGuiaECO" INTEGER;
