-- AlterTable
ALTER TABLE "public"."Protocolo" ADD COLUMN     "descricao_resolucao" TEXT;
