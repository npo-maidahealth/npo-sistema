-- AlterTable
ALTER TABLE "public"."Prioridade" ADD COLUMN     "fonte" TEXT DEFAULT 'ECO';
